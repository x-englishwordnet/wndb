This resource is derived from Princeton WordNet under the WordNet License
and further developed under the Creative Commons Attribution 4.0 International License.
You may share and adapt this resource providing attribution is given to both
Princeton WordNet and the English WordNet team.

[WN](https://wordnet.princeton.edu/license-and-commercial-use)

[OEWN](https://creativecommons.org/licenses/by/4.0/)